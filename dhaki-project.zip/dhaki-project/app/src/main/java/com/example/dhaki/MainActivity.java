package com.example.dhaki;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32,48,32,32);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("ذكي");
        title.setTextSize(32);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        root.addView(title,new LinearLayout.LayoutParams(-1,100));

        TextView sub = new TextView(this);
        sub.setText("وكيل ذكي للتحكم بالهاتف");
        sub.setTextSize(18);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub,new LinearLayout.LayoutParams(-1,80));

        Button open = new Button(this);
        open.setText("تفعيل خدمة التحكم");
        root.addView(open,new LinearLayout.LayoutParams(-1,70));

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0,30,0,0);
        root.addView(status,new LinearLayout.LayoutParams(-1,150));

        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        setContentView(root);
        update();
    }
    @Override protected void onResume(){ super.onResume(); update(); }
    void update(){
        status.setText(AgentAccessibilityService.instance != null
            ? "✓ خدمة ذكي مفعلة\nيمكن للوكيل الآن قراءة الواجهة وتنفيذ الأوامر."
            : "خدمة ذكي غير مفعلة\nاضغط الزر ثم فعّل ذكي من خدمات إمكانية الوصول.");
    }
}
