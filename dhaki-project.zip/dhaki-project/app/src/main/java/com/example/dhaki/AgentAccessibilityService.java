package com.example.dhaki;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.*;
import java.io.*;
import java.util.*;

public class AgentAccessibilityService extends AccessibilityService {
    public static volatile AgentAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private File rootDir, commandFile, resultFile, stateFile;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        rootDir = new File(getExternalFilesDir(null),"bridge");
        rootDir.mkdirs();
        commandFile = new File(rootDir,"agent_command.json");
        resultFile = new File(rootDir,"agent_result.json");
        stateFile = new File(rootDir,"ui_state.json");
        handler.post(poller);
    }

    @Override public void onDestroy() {
        instance = null;
        handler.removeCallbacks(poller);
        super.onDestroy();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){ writeState(); }
    @Override public void onInterrupt(){}

    private final Runnable poller = () -> {
        try {
            if(commandFile != null && commandFile.exists() && commandFile.length()>0){
                String c = read(commandFile);
                if(c.contains(""action"")){
                    String r = execute(c);
                    write(resultFile,r);
                    new FileOutputStream(commandFile).close();
                }
            }
            writeState();
        } catch(Exception ignored){}
        handler.postDelayed(poller,350);
    };

    private String execute(String c) {
        try {
            String a=value(c,"action");
            if("back".equals(a)){ performGlobalAction(GLOBAL_ACTION_BACK); return ok("back"); }
            if("home".equals(a)){ performGlobalAction(GLOBAL_ACTION_HOME); return ok("home"); }
            if("tap".equals(a)){
                AccessibilityNodeInfo n=find(c);
                if(n==null)return err("element_not_found");
                Rect r=new Rect(); n.getBoundsInScreen(r);
                click(r.centerX(),r.centerY());
                return ok("tap");
            }
            if("type".equals(a)){
                AccessibilityNodeInfo n=find(c);
                if(n==null)return err("editable_not_found");
                String t=value(c,"text");
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                Bundle b=new Bundle();
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,t);
                boolean ok=n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);
                return ok ? ok("type") : err("set_text_rejected");
            }
            if("swipe".equals(a)){
                float x1=num(c,"x1",0),y1=num(c,"y1",0),x2=num(c,"x2",0),y2=num(c,"y2",0);
                Path p=new Path(); p.moveTo(x1,y1); p.lineTo(x2,y2);
                GestureDescription g=new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p,0,500)).build();
                dispatchGesture(g,null,null);
                return ok("swipe");
            }
            if("open_app".equals(a)){
                String pkg=value(c,"package");
                android.content.Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
                if(i==null)return err("package_not_found");
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return ok("open_app");
            }
            return err("unknown_action");
        } catch(Exception e){ return err(e.getClass().getSimpleName()); }
    }

    private AccessibilityNodeInfo find(String c){
        return findRec(getRootInActiveWindow(),value(c,"text"),value(c,"resource_id"),value(c,"content_desc"));
    }
    private AccessibilityNodeInfo findRec(AccessibilityNodeInfo n,String text,String id,String desc){
        if(n==null)return null;
        if(id!=null&&!id.isEmpty()&&id.equals(n.getViewIdResourceName()))return n;
        if(text!=null&&!text.isEmpty()&&text.equals(String.valueOf(n.getText())))return n;
        if(desc!=null&&!desc.isEmpty()&&desc.equals(String.valueOf(n.getContentDescription())))return n;
        for(int i=0;i<n.getChildCount();i++){
            AccessibilityNodeInfo r=findRec(n.getChild(i),text,id,desc);
            if(r!=null)return r;
        }
        return null;
    }

    private void click(float x,float y){
        Path p=new Path(); p.moveTo(x,y);
        dispatchGesture(new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,80)).build(),null,null);
    }

    private void writeState(){
        try{
            AccessibilityNodeInfo r=getRootInActiveWindow();
            StringBuilder s=new StringBuilder("{"package":"")
                .append(r==null?"":r.getPackageName()).append("","nodes":[");
            ArrayList<AccessibilityNodeInfo> q=new ArrayList<>();
            if(r!=null)q.add(r);
            boolean first=true;
            while(!q.isEmpty()){
                AccessibilityNodeInfo n=q.remove(0);
                Rect b=new Rect();n.getBoundsInScreen(b);
                if(!first)s.append(',');
                first=false;
                s.append("{"text":"").append(esc(n.getText()))
                 .append("","id":"").append(esc(n.getViewIdResourceName()))
                 .append("","desc":"").append(esc(n.getContentDescription()))
                 .append("","clickable":").append(n.isClickable())
                 .append(","editable":").append(n.isEditable())
                 .append(","bounds":[").append(b.left).append(',')
                 .append(b.top).append(',').append(b.right).append(',')
                 .append(b.bottom).append("]}");
                for(int i=0;i<n.getChildCount();i++)q.add(n.getChild(i));
            }
            s.append("]}");
            write(stateFile,s.toString());
        }catch(Exception ignored){}
    }

    private String esc(CharSequence x){
        return x==null?"":String.valueOf(x).replace("\","\\").replace(""","\"").replace("
","\n");
    }
    private String read(File f)throws Exception{
        return new String(java.nio.file.Files.readAllBytes(f.toPath()),"UTF-8");
    }
    private void write(File f,String s)throws Exception{
        try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes("UTF-8"));}
    }
    private String value(String j,String k){
        String p="""+k+"""; int i=j.indexOf(p); if(i<0)return "";
        i=j.indexOf(':',i); if(i<0)return ""; i++;
        while(i<j.length()&&Character.isWhitespace(j.charAt(i)))i++;
        if(i<j.length()&&j.charAt(i)=='"'){
            int e=j.indexOf('"',i+1); return e<0?"":j.substring(i+1,e);
        }
        int e=i; while(e<j.length()&&",}".indexOf(j.charAt(e))<0)e++;
        return j.substring(i,e).trim();
    }
    private float num(String j,String k,float d){try{return Float.parseFloat(value(j,k));}catch(Exception e){return d;}}
    private String ok(String message) {
        return "{\"ok\":true,\"message\":\"" + escapeJson(message) + "\"}";
    }

    private String err(String message) {
        return "{\"ok\":false,\"error\":\"" + escapeJson(message) + "\"}";
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
